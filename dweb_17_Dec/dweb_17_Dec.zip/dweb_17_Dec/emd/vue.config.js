module.exports = {
  'transpileDependencies': [
    'vuetify'
  ]
}
