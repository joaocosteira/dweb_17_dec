<template>
    <div>
        <p v-if="!emdsReady">A carregar exames...</p>
        <Lista v-else : lista:"emds" />
    </div>    
</template>

<script>
    import Lista from '@/components/Lista.vue'
    import axios from "axios"
    const h = require("@/config/hosts")

export default{
    name: 'listaEMD',
    components: {
        Lista
    },

    data: () =>({

        emds: [],
        emdsReady: false
    }),

    created: async function(){

        try{
            let response = await axios.get(h + "/emds")
            this.emds = response.data 
            this.emdsReady = true 
        }catch (e){
            return e
        }
    }
}
</script>
