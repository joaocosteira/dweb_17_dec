<template>
    <v-card class="ma-8">
        <v-card-title class="indigo darken-4 white--text" dark>
            Lista de Exames Médico Desportivo
    </v-card-title>

    <v-card-text>
        <v-data-table
            :headers="headers"
            :items="mylista"
            class="elevation-1"
            :footer-props="footer_props"
        >       
        <template v-slot:item="props">
            <tr>
                <td v-for="(compo,index) in props.item" v-bind:key="index">
                    {{ compo }}
                </td>
                <td>
                    <v-icon
                        @click="showExame(props.item.id)"
                        color="indigo darken-2"
                        >visibility</v-icon
                    >
                </td>
            </tr>                         
</template>

<template v-slot:pageText="props">
    Resultados: {{}}
<script>

</script>
